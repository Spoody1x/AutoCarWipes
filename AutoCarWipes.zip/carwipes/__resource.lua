client_script 'delallvehcl.lua'
server_script 'delallvehsv.lua'

-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900
-- Scripted by Spoody1X / Spoody#0900